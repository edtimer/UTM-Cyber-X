# UTM Cyber-X puzzle page

This page contains a puzzle for prospective recruits at UTM

## Misc

Follow us: [Facebook](https://www.facebook.com/utmcyberx/), [Instagram](https://www.instagram.com/utmcyberx/)

[© Codrops 2022](http://utmcyberx.tech)
